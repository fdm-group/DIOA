<!-- footer section -->
<style>
  #contact{
    padding: 50px;
  }
</style>
<section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto text-center">
          <h2 class="section-heading">Get In Touch!</h2>
          <hr class="my-4">
<center><p>Created by FDM</p></center>
        </div>
      </div>

      <!--  <div class="row">

      <div class="col-lg-4 ml-auto text-center">
          <i class="fa fa-phone fa-3x mb-3 sr-contact"></i>
          <p>123-456-6789</p>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fa fa-envelope-o fa-3x mb-3 sr-contact"></i>
          <p>
            <a href="mailto:your-email@your-domain.com">feedback@startbootstrap.com</a>
          </p>
        </div>
      </div>

    -->

  </div>
  </section>

<?php wp_footer(); ?>
</body>
</html>
