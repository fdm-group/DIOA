<?php get_header(); ?>

<style>
.content{
    padding-bottom: 100px;
    padding-top: 100px;
    background-color: #F1F1F1;
    padding-left: 100px;
    padding-right: 100px;
    background-color: #fff;
}

</style>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand js-scroll-trigger" href="#page-top">Logo</a>

<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive"
aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

        <?php
            wp_nav_menu( array(
            'theme_location' => 'my-custom-menu',
            'menu_class' => 'main_menu' ) );
        ?>
    <!--
      <ul class="navbar-nav ml-auto" >    <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="home.html">Home</a>
        </li>
      </ul>
      -->
    </div>
  </div>
</nav>
<!-- header images -->
<header class="pagehead text-center text-white d-flex" id="pageheader">
<div class="container my-auto">
	<div class="row">
		<div class="col-lg-10 mx-auto">
			<h1 class="text-uppercase">
				<strong><?php the_title(); ?></strong>
			</h1>
			<hr class="hr">
		</div>
	</div>
</div>
</header>
<hr>

<div class="content ">

  <?php
  while ( have_posts() ) :
    the_post();

    ?>


    <?php

    the_content();

  endwhile;
  ?>

</div>


<div id="sections" class="mx-auto">
<?php
// check if the repeater field has rows of data
if( have_rows('members') ):
  ?>
     <center><h1><?php the_title(); ?></h1></center>
    <?php
 	// loop through the rows of data
    while ( have_rows('members') ) : the_row();
      $image = get_sub_field('image')['url'];


        // display a sub field value
      ?>

      <div class="col-md-4 col-sm-4">
             <div class="team-member">
                 <div class="team-img">
                     <img src="<?php echo $image; ?>" alt="team member" class="img-responsive" width="400" height="400">
                 </div>
                 <div class="team-hover">
                     <div class="desk">
                             <p> <?php the_sub_field('description')?></p>
                     </div>

                 </div>
             </div>
             <div class="team-title">
                 <h5><?php the_sub_field('name'); ?></h5>
                 <span><?php the_sub_field('job_title'); ?></span>
             </div>
      </div>
      <?php

    endwhile;

else :

    // no rows found

endif;

?>
<?php
// check if the repeater field has rows of data
if( have_rows('download_courses') ):

?> <center><h1><?php the_title(); ?></h1></center>
<?php
 	// loop through the rows of data
    while ( have_rows('download_courses') ) : the_row();

        // display a sub field value
      ?>

    <p>  <a href="<?php the_sub_field('download'); ?>" download="<?php the_sub_field('name');?>"><?php the_sub_field('name');?></a></p>


      <?php

    endwhile;

else :

    // no rows found

endif;


?>

<?php
// check if the repeater field has rows of data
if( have_rows('testimonial') ):
?>   <center><h1><?php the_title(); ?></h1></center>

<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src=".../800x400?auto=yes&bg=777&fg=555&text=First slide" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src=".../800x400?auto=yes&bg=666&fg=444&text=Second slide" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src=".../800x400?auto=yes&bg=555&fg=333&text=Third slide" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<?php
 	// loop through the rows of data
    while ( have_rows('testimonial') ) : the_row();

        // display a sub field value
      ?>


      <img src="<?php the_sub_field('headshot')?>" alt="<?php get_field('name'); ?>" />

    <h1> <?php the_sub_field('name')?></h1>
    <h3> <?php the_sub_field('job_title')?></h3>
    <p> <?php the_sub_field('text')?></p>


      <?php

    endwhile;

else :

    // no rows found

endif;


?>

<?php
// check if the repeater field has rows of data
if( have_rows('companies') ):
?>  <center><h1><?php the_title(); ?></h1></center>

<?php
 	// loop through the rows of data
    while ( have_rows('companies') ) : the_row();

        // display a sub field value
      ?>


      <img src="<?php the_sub_field('logo')?>" alt="<?php get_field('business_name'); ?>" />

    <h1> <?php the_sub_field('business_name')?></h1>


      <?php

    endwhile;

else :

    // no rows found

endif;


?>

<?php
// check if the repeater field has rows of data
if( have_rows('support_team') ):
?>   <center><h1><?php the_title(); ?></h1></center>

<?php
 	// loop through the rows of data
    while ( have_rows('support_team') ) : the_row();

        // display a sub field value
            $image = get_sub_field('image')['url'];
      ?>

                          <div class="col-md-4 col-sm-4">
                                 <div class="team-member">
                                     <div class="team-img">
                                         <img src="<?php echo $image; ?>" alt="team member" class="img-responsive" width="400" height="400">
                                     </div>
                                     <div class="team-hover">
                                         <div class="desk">
                                                 <p> <?php the_sub_field('text')?></p>
                                         </div>

                                     </div>
                                 </div>
                                 <div class="team-title">
                                     <h5><?php the_sub_field('name'); ?></h5>
                                     <span><?php the_sub_field('job_title'); ?></span>
                                 </div>
                          </div>
      <?php

    endwhile;

else :

    // no rows found

endif;


?>

</div>

<script>
$('.carousel').carousel({
  interval: 2000
});
</script>

<?php get_footer(); ?>
