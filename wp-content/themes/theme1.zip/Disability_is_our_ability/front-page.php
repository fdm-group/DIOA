<?php

/*
Template Name: front page custom page
*/

get_header(); ?>
<style>

</style>

<!-- Navigation -->

 <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
	 <div class="container">
		 <a class="navbar-brand js-scroll-trigger" href="#page-top">Logo</a>

 <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive"
 aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			 <span class="navbar-toggler-icon"></span>
		 </button>

		 <div class="collapse navbar-collapse" id="navbarResponsive">

				 <?php
						 wp_nav_menu( array(
						 'theme_location' => 'my-custom-menu',
						 'menu_class' => 'front-page' ) );
				 ?>

		 <!--
			 <ul class="navbar-nav ml-auto" >    <li class="nav-item">
					 <a class="nav-link js-scroll-trigger" href="home.html">Home</a>
				 </li>
			 </ul>
			 -->


		 </div>
	 </div>
 </nav>

<!-- header images -->
<header class="masthead text-center text-white d-flex">
<div class="container my-auto">
	<div class="row">
		<div class="col-lg-10 mx-auto">
			<h1 class="text-uppercase">
				<strong>Charity Page</strong>
			</h1>
			<hr class="hr">
		</div>
		<div class="col-lg-8 mx-auto">
			<p class="text-faded mb-5"> </p>
			<a class="btn btn-info btn-xl js-scroll-trigger" href="#about" style="font-size: 1.2em; padding-15px;">Find Out More</a>
		</div>
	</div>
</div>
</header>

<div class="content">

					<?php
					while ( have_posts() ) :
						the_post();


						the_content();

					endwhile;
					?>






		</div> <!-- /.sections -->


<?php get_footer(); ?>
